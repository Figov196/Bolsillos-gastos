package com.fidel.mis_bolsillos
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
