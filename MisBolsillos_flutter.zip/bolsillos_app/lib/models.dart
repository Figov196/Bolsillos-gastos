// lib/models.dart
import 'dart:convert';

const double tSalud = 0.125;
const double tPension = 0.16;

const List<Map<String, dynamic>> defaultCats = [
  {'n': 'Imprevistos',      'pct': 7.0,  'seg': false},
  {'n': 'Arriendo',         'pct': 30.0, 'seg': false},
  {'n': 'Comida',           'pct': 25.0, 'seg': false},
  {'n': 'Salud',            'pct': 6.0,  'seg': false},
  {'n': 'Ropa/Ocio',        'pct': 7.0,  'seg': false},
  {'n': 'Otros',            'pct': 3.0,  'seg': false},
  {'n': 'Restante',         'pct': 22.0, 'seg': false},
  {'n': 'Préstamo',         'pct': 0.0,  'seg': false},
  {'n': 'Viáticos',         'pct': 0.0,  'seg': false},
  {'n': 'Seguridad Social', 'pct': 0.0,  'seg': true },
];

const List<Map<String, dynamic>> arlNiveles = [
  {'label': 'Riesgo I — 0.522%',   'value': 0.00522},
  {'label': 'Riesgo II — 1.044%',  'value': 0.01044},
  {'label': 'Riesgo III — 2.436%', 'value': 0.02436},
  {'label': 'Riesgo IV — 4.350%',  'value': 0.04350},
  {'label': 'Riesgo V — 6.960%',   'value': 0.06960},
];

class Categoria {
  String n;
  double pct;
  bool seg;
  Categoria({required this.n, required this.pct, required this.seg});
  factory Categoria.fromMap(Map<String, dynamic> m) =>
      Categoria(n: m['n'], pct: (m['pct'] as num).toDouble(), seg: m['seg'] ?? false);
  Map<String, dynamic> toMap() => {'n': n, 'pct': pct, 'seg': seg};
}

class Movimiento {
  final int id;
  final String fecha;
  final String tipo;
  final String cat;
  final String det;
  final double val;
  Movimiento({required this.id, required this.fecha, required this.tipo,
      required this.cat, required this.det, required this.val});
  factory Movimiento.fromMap(Map<String, dynamic> m) => Movimiento(
      id: m['id'], fecha: m['fecha'], tipo: m['tipo'],
      cat: m['cat'], det: m['det'] ?? '', val: (m['val'] as num).toDouble());
  Map<String, dynamic> toMap() =>
      {'id': id, 'fecha': fecha, 'tipo': tipo, 'cat': cat, 'det': det, 'val': val};
}

class MesData {
  double bruto;
  bool segActiva;
  double arl;
  double ingNeto;
  List<Movimiento> movimientos;
  MesData({this.bruto = 0, this.segActiva = false, this.arl = 0.00522,
      this.ingNeto = 0, List<Movimiento>? movimientos})
      : movimientos = movimientos ?? [];

  double get segTotal {
    if (!segActiva || bruto == 0) return 0;
    final ibc = bruto * 0.4;
    return ibc * (tSalud + tPension + arl);
  }

  double get ingBase => segActiva ? ingNeto : bruto;

  factory MesData.fromMap(Map<String, dynamic> m) => MesData(
      bruto: (m['bruto'] as num?)?.toDouble() ?? 0,
      segActiva: m['segActiva'] ?? false,
      arl: (m['arl'] as num?)?.toDouble() ?? 0.00522,
      ingNeto: (m['ingNeto'] as num?)?.toDouble() ?? 0,
      movimientos: (m['movimientos'] as List? ?? [])
          .map((e) => Movimiento.fromMap(e)).toList());

  Map<String, dynamic> toMap() => {
        'bruto': bruto, 'segActiva': segActiva, 'arl': arl, 'ingNeto': ingNeto,
        'movimientos': movimientos.map((e) => e.toMap()).toList(),
      };
}

class AppState {
  int mes;
  List<Categoria> cats;
  Map<int, MesData> meses;

  AppState({required this.mes, required this.cats, required this.meses});

  factory AppState.defaultState() => AppState(
      mes: DateTime.now().month - 1,
      cats: defaultCats.map((e) => Categoria.fromMap(e)).toList(),
      meses: {});

  factory AppState.fromJson(String raw) {
    final m = jsonDecode(raw);
    return AppState(
      mes: m['mes'] ?? DateTime.now().month - 1,
      cats: (m['cats'] as List? ?? defaultCats).map((e) => Categoria.fromMap(e)).toList(),
      meses: (m['meses'] as Map<String, dynamic>? ?? {})
          .map((k, v) => MapEntry(int.parse(k), MesData.fromMap(v))),
    );
  }

  String toJson() => jsonEncode({
        'mes': mes,
        'cats': cats.map((e) => e.toMap()).toList(),
        'meses': meses.map((k, v) => MapEntry(k.toString(), v.toMap())),
      });

  MesData getMes(int i) {
    meses[i] ??= MesData();
    return meses[i]!;
  }
}
