// lib/services/drive_service.dart
import 'dart:convert';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;

class DriveService {
  static final _googleSignIn = GoogleSignIn(
    scopes: [
      'email',
      'https://www.googleapis.com/auth/drive.file',
    ],
  );

  static GoogleSignInAccount? _currentUser;
  static GoogleSignInAccount? get currentUser => _currentUser;
  static bool get isSignedIn => _currentUser != null;

  static Future<GoogleSignInAccount?> signIn() async {
    try {
      _currentUser = await _googleSignIn.signIn();
      return _currentUser;
    } catch (e) {
      return null;
    }
  }

  static Future<void> signOut() async {
    await _googleSignIn.signOut();
    _currentUser = null;
  }

  static Future<GoogleSignInAccount?> signInSilently() async {
    try {
      _currentUser = await _googleSignIn.signInSilently();
      return _currentUser;
    } catch (_) {
      return null;
    }
  }

  static Future<Map<String, String>?> _getHeaders() async {
    if (_currentUser == null) return null;
    final auth = await _currentUser!.authentication;
    return {'Authorization': 'Bearer ${auth.accessToken}', 'Content-Type': 'application/json'};
  }

  /// Busca una carpeta "Mis Bolsillos" en Drive, la crea si no existe
  static Future<String?> _getOrCreateFolder() async {
    final headers = await _getHeaders();
    if (headers == null) return null;

    // Buscar carpeta existente
    final searchRes = await http.get(
      Uri.parse(
        "https://www.googleapis.com/drive/v3/files"
        "?q=name='Mis Bolsillos' and mimeType='application/vnd.google-apps.folder' and trashed=false"
        "&fields=files(id,name)"
      ),
      headers: headers,
    );

    if (searchRes.statusCode == 200) {
      final body = jsonDecode(searchRes.body);
      final files = body['files'] as List;
      if (files.isNotEmpty) return files[0]['id'];
    }

    // Crear carpeta
    final createRes = await http.post(
      Uri.parse('https://www.googleapis.com/drive/v3/files'),
      headers: headers,
      body: jsonEncode({'name': 'Mis Bolsillos', 'mimeType': 'application/vnd.google-apps.folder'}),
    );

    if (createRes.statusCode == 200) {
      return jsonDecode(createRes.body)['id'];
    }
    return null;
  }

  /// Sube o actualiza el CSV en Drive
  static Future<bool> uploadCSV(String csvContent, String filename) async {
    final headers = await _getHeaders();
    if (headers == null) return false;

    final folderId = await _getOrCreateFolder();
    if (folderId == null) return false;

    // Buscar si ya existe el archivo
    final searchRes = await http.get(
      Uri.parse(
        "https://www.googleapis.com/drive/v3/files"
        "?q=name='$filename' and '$folderId' in parents and trashed=false"
        "&fields=files(id)"
      ),
      headers: headers,
    );

    final csvBytes = utf8.encode(csvContent);
    final boundary = '-------314159265358979323846';

    String? existingId;
    if (searchRes.statusCode == 200) {
      final files = jsonDecode(searchRes.body)['files'] as List;
      if (files.isNotEmpty) existingId = files[0]['id'];
    }

    final metadata = existingId == null
        ? jsonEncode({'name': filename, 'parents': [folderId], 'mimeType': 'text/csv'})
        : jsonEncode({'name': filename});

    final body = '--$boundary\r\n'
        'Content-Type: application/json; charset=UTF-8\r\n\r\n'
        '$metadata\r\n'
        '--$boundary\r\n'
        'Content-Type: text/csv\r\n\r\n'
        '${utf8.decode(csvBytes)}\r\n'
        '--$boundary--';

    final uploadHeaders = {
      ...headers,
      'Content-Type': 'multipart/related; boundary=$boundary',
    };

    http.Response res;
    if (existingId != null) {
      res = await http.patch(
        Uri.parse('https://www.googleapis.com/upload/drive/v3/files/$existingId?uploadType=multipart'),
        headers: uploadHeaders,
        body: body,
      );
    } else {
      res = await http.post(
        Uri.parse('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart'),
        headers: uploadHeaders,
        body: body,
      );
    }

    return res.statusCode == 200;
  }
}
