// lib/theme.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const kBg     = Color(0xFF0A0A0A);
const kS1     = Color(0xFF141414);
const kS2     = Color(0xFF1E1E1E);
const kS3     = Color(0xFF282828);
const kBorder = Color(0xFF2A2A2A);
const kAccent = Color(0xFFB8F050);
const kA2     = Color(0xFF50C8F0);
const kA3     = Color(0xFFF0A050);
const kDanger = Color(0xFFF05050);
const kText   = Color(0xFFEFEFEF);
const kMuted  = Color(0xFF555555);

ThemeData appTheme() => ThemeData(
  brightness: Brightness.dark,
  scaffoldBackgroundColor: kBg,
  colorScheme: const ColorScheme.dark(
    primary: kAccent, secondary: kA2, surface: kS1, error: kDanger,
  ),
  textTheme: GoogleFonts.dmMonoTextTheme(ThemeData.dark().textTheme)
      .apply(bodyColor: kText, displayColor: kText),
  appBarTheme: AppBarTheme(
    backgroundColor: kS1, elevation: 0, centerTitle: false,
    titleTextStyle: GoogleFonts.syne(fontSize: 18, fontWeight: FontWeight.w800, color: kText),
  ),
  bottomNavigationBarTheme: const BottomNavigationBarThemeData(
    backgroundColor: kS1, selectedItemColor: kAccent,
    unselectedItemColor: kMuted, type: BottomNavigationBarType.fixed, elevation: 0,
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true, fillColor: kS2,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: kBorder)),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: kBorder)),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: kAccent)),
    labelStyle: const TextStyle(color: kMuted, fontSize: 12),
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
  ),
  cardTheme: CardTheme(
    color: kS1, elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: kBorder)),
    margin: const EdgeInsets.only(bottom: 14),
  ),
  dividerColor: kBorder,
  useMaterial3: true,
);

TextStyle syneStyle({double size = 14, FontWeight weight = FontWeight.w700, Color color = kText}) =>
    TextStyle(fontFamily: 'Syne', fontSize: size, fontWeight: weight, color: color);

String fCOP(double v) {
  final abs = v.abs();
  final f = abs >= 1000000 ? '\$${(abs/1000000).toStringAsFixed(1)}M'
      : abs >= 1000 ? '\$${(abs/1000).toStringAsFixed(0)}K'
      : '\$${abs.toStringAsFixed(0)}';
  return v < 0 ? '-$f' : f;
}

String fCOPFull(double v) {
  final n = v.abs().toStringAsFixed(0)
      .replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');
  return v < 0 ? '-\$$n' : '\$$n';
}
