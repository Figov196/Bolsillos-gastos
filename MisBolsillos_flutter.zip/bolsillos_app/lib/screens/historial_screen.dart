// lib/screens/historial_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/mes_selector.dart';

class HistorialScreen extends StatelessWidget {
  const HistorialScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<BolsillosProvider>();
    final movs = [...prov.s.getMes(prov.s.mes).movimientos.reversed];

    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16,16,16,8), child: const MesSelector()),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Text('MOVIMIENTOS', style: syneStyle(size: 11, color: kMuted)),
          const SizedBox(width: 8),
          Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(color: kS2, borderRadius: BorderRadius.circular(10)),
            child: Text('${movs.length}', style: const TextStyle(fontSize: 11, color: kMuted))),
          const Spacer(),
          const Text('← desliza para eliminar', style: TextStyle(fontSize: 10, color: kMuted)),
        ])),
      const SizedBox(height: 8),
      Expanded(child: movs.isEmpty
        ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.receipt_long_outlined, color: kMuted, size: 48),
            const SizedBox(height: 12),
            Text('Sin movimientos este mes', style: syneStyle(size: 13, color: kMuted)),
          ]))
        : ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            itemCount: movs.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final m = movs[i];
              final isIng = m.tipo == 'Ingreso';
              return Dismissible(
                key: Key(m.id.toString()),
                direction: DismissDirection.endToStart,
                background: Container(alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 16),
                  color: kDanger.withOpacity(0.2),
                  child: const Icon(Icons.delete_outline, color: kDanger)),
                onDismissed: (_) {
                  prov.deleteMovimiento(m.id);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Eliminado'), duration: Duration(seconds: 2)));
                },
                child: Padding(padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Row(children: [
                    Container(width: 36, height: 36,
                      decoration: BoxDecoration(
                        color: (isIng ? kAccent : kDanger).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(8)),
                      child: Icon(isIng ? Icons.arrow_downward : Icons.arrow_upward,
                        color: isIng ? kAccent : kDanger, size: 18)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(m.det.isNotEmpty ? '${m.cat} · ${m.det}' : m.cat,
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 2),
                      Text('${m.fecha} · ${m.tipo}', style: const TextStyle(fontSize: 11, color: kMuted)),
                    ])),
                    const SizedBox(width: 8),
                    Text('${isIng ? "+" : "-"}${fCOPFull(m.val)}',
                      style: syneStyle(size: 13, color: isIng ? kAccent : kDanger)),
                  ])),
              );
            },
          )),
    ]);
  }
}
