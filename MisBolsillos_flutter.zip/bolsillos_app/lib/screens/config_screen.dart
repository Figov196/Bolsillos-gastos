// lib/screens/config_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models.dart';
import '../services/drive_service.dart';
import '../state.dart';
import '../theme.dart';

class ConfigScreen extends StatefulWidget {
  const ConfigScreen({super.key});
  @override
  State<ConfigScreen> createState() => _ConfigScreenState();
}

class _ConfigScreenState extends State<ConfigScreen> {
  late List<TextEditingController> _ctrls;
  bool _initDone = false;
  bool _syncing = false;

  void _initCtrls(List<Categoria> cats) {
    if (_initDone) return;
    _ctrls = cats.map((c) => TextEditingController(text: c.pct.toStringAsFixed(0))).toList();
    _initDone = true;
  }

  double _totalPct(List<Categoria> cats) => _ctrls.asMap().entries
      .where((e) => !cats[e.key].seg)
      .map((e) => double.tryParse(e.value.text) ?? 0)
      .fold(0, (a, b) => a + b);

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<BolsillosProvider>();
    _initCtrls(prov.s.cats);
    final total = _totalPct(prov.s.cats);
    final ok = (total - 100).abs() < 0.1;
    final isSignedIn = DriveService.isSignedIn;
    final user = DriveService.currentUser;

    return ListView(padding: const EdgeInsets.all(16), children: [

      // GOOGLE DRIVE SYNC
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 7, height: 7, decoration: const BoxDecoration(color: kA2, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Text('Google Drive', style: syneStyle(size: 13)),
          ]),
          const SizedBox(height: 14),
          if (isSignedIn) ...[
            Row(children: [
              CircleAvatar(radius: 16,
                backgroundImage: user?.photoUrl != null ? NetworkImage(user!.photoUrl!) : null,
                backgroundColor: kS3,
                child: user?.photoUrl == null ? const Icon(Icons.person, size: 16, color: kMuted) : null),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(user?.displayName ?? '', style: const TextStyle(fontSize: 13)),
                Text(user?.email ?? '', style: const TextStyle(fontSize: 11, color: kMuted)),
              ])),
              TextButton(onPressed: () async {
                await DriveService.signOut();
                setState(() {});
              }, child: const Text('Salir', style: TextStyle(color: kDanger, fontSize: 12))),
            ]),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity,
              child: ElevatedButton.icon(
                icon: _syncing
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                  : const Icon(Icons.cloud_upload_outlined, size: 18),
                label: Text(_syncing ? 'Subiendo...' : 'Guardar CSV en Drive',
                  style: syneStyle(size: 13, color: Colors.black)),
                onPressed: _syncing ? null : () => _syncDrive(context, prov),
                style: ElevatedButton.styleFrom(backgroundColor: kA2, foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              )),
            const SizedBox(height: 8),
            Container(padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: kS2, borderRadius: BorderRadius.circular(8)),
              child: const Text(
                'El CSV se guarda en una carpeta "Mis Bolsillos" en tu Drive. Si ya existe, lo reemplaza.',
                style: TextStyle(fontSize: 11, color: kMuted, height: 1.6))),
          ] else ...[
            const Text('Inicia sesión para guardar el CSV directamente en tu Google Drive como respaldo.',
              style: TextStyle(fontSize: 12, color: kMuted, height: 1.6)),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.login, size: 18),
                label: Text('Iniciar sesión con Google', style: syneStyle(size: 13, color: Colors.black)),
                onPressed: () async {
                  final user = await DriveService.signIn();
                  if (user != null) setState(() {});
                  else if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('No se pudo iniciar sesión'), backgroundColor: kDanger));
                  }
                },
                style: ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              )),
          ],
          const SizedBox(height: 10),
          // Compartir CSV siempre disponible
          SizedBox(width: double.infinity,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.share_outlined, size: 16),
              label: const Text('Compartir CSV', style: TextStyle(fontSize: 13)),
              onPressed: () => _shareCSV(context, prov),
              style: OutlinedButton.styleFrom(foregroundColor: kMuted,
                side: const BorderSide(color: kBorder),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            )),
        ],
      ))),

      // DISTRIBUCIÓN
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 7, height: 7, decoration: const BoxDecoration(color: kA3, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Text('Distribución por categoría', style: syneStyle(size: 13)),
          ]),
          const SizedBox(height: 4),
          const Text('Debe sumar 100%', style: TextStyle(fontSize: 11, color: kMuted)),
          const SizedBox(height: 14),
          ...prov.s.cats.asMap().entries.map((e) {
            final cat = e.value;
            return Padding(padding: const EdgeInsets.only(bottom: 12),
              child: Row(children: [
                Expanded(child: Text(cat.n, style: const TextStyle(fontSize: 13))),
                if (cat.seg)
                  Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(color: kS2, borderRadius: BorderRadius.circular(6)),
                    child: const Text('auto', style: TextStyle(fontSize: 12, color: kA3)))
                else ...[
                  SizedBox(width: 70, child: TextField(
                    controller: _ctrls[e.key],
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    textAlign: TextAlign.right,
                    style: syneStyle(size: 15, color: kAccent),
                    onChanged: (_) => setState(() {}),
                    decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8)),
                  )),
                  const SizedBox(width: 4),
                  const Text('%', style: TextStyle(color: kMuted, fontSize: 13)),
                ],
              ]));
          }),
          const Divider(),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Total:', style: syneStyle(size: 13, color: kMuted)),
            Text('${total.toStringAsFixed(1)}%', style: syneStyle(size: 15, color: ok ? kAccent : kDanger)),
          ]),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity,
            child: ElevatedButton(
              onPressed: ok ? () {
                final newCats = prov.s.cats.asMap().entries.map((e) {
                  final c = Categoria(n: e.value.n, pct: e.value.pct, seg: e.value.seg);
                  if (!c.seg) c.pct = double.tryParse(_ctrls[e.key].text) ?? c.pct;
                  return c;
                }).toList();
                prov.saveCats(newCats);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Distribución guardada ✓'), backgroundColor: kAccent));
              } : null,
              style: ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: Colors.black,
                disabledBackgroundColor: kS3,
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              child: Text('Guardar distribución', style: syneStyle(size: 13, color: ok ? Colors.black : kMuted)),
            )),
        ],
      ))),

      // ZONA PELIGROSA
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 7, height: 7, decoration: const BoxDecoration(color: kDanger, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Text('Zona peligrosa', style: syneStyle(size: 13)),
          ]),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity,
            child: ElevatedButton(
              onPressed: () => _confirmarBorrar(context, prov),
              style: ElevatedButton.styleFrom(
                backgroundColor: kDanger.withOpacity(0.15), foregroundColor: kDanger,
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10), side: const BorderSide(color: kDanger))),
              child: Text('Borrar datos de este mes', style: syneStyle(size: 13, color: kDanger)),
            )),
        ],
      ))),
      const SizedBox(height: 20),
    ]);
  }

  Future<void> _syncDrive(BuildContext context, BolsillosProvider prov) async {
    setState(() => _syncing = true);
    final csv = prov.buildCSV();
    final fecha = DateTime.now().toIso8601String().split('T')[0];
    final ok = await DriveService.uploadCSV(csv, 'MisBolsillos_$fecha.csv');
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(ok ? '✓ Guardado en Drive → carpeta "Mis Bolsillos"' : 'Error al subir a Drive'),
        backgroundColor: ok ? kAccent : kDanger,
        duration: const Duration(seconds: 3)));
    }
    setState(() => _syncing = false);
  }

  Future<void> _shareCSV(BuildContext context, BolsillosProvider prov) async {
    final csv = prov.buildCSV();
    final dir = await getTemporaryDirectory();
    final fecha = DateTime.now().toIso8601String().split('T')[0];
    final file = File('${dir.path}/MisBolsillos_$fecha.csv');
    await file.writeAsString(csv);
    await Share.shareXFiles([XFile(file.path)], text: 'Mis Bolsillos — Exportación CSV');
  }

  void _confirmarBorrar(BuildContext context, BolsillosProvider prov) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: kS2,
      title: Text('¿Borrar este mes?', style: syneStyle(size: 16)),
      content: const Text('Se eliminarán todos los movimientos e ingresos del mes.',
        style: TextStyle(color: kMuted, fontSize: 13)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar', style: TextStyle(color: kMuted))),
        ElevatedButton(onPressed: () { prov.borrarMes(); Navigator.pop(context); },
          style: ElevatedButton.styleFrom(backgroundColor: kDanger),
          child: Text('Borrar', style: syneStyle(size: 13, color: Colors.white))),
      ],
    ));
  }
}
