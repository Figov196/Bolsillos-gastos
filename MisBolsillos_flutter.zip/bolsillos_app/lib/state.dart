// lib/state.dart
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class BolsillosProvider extends ChangeNotifier {
  AppState _s = AppState.defaultState();
  AppState get s => _s;

  BolsillosProvider() { _load(); }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('bolsillos_v4');
    if (raw != null) { try { _s = AppState.fromJson(raw); } catch (_) {} }
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('bolsillos_v4', _s.toJson());
  }

  void setMes(int i) { _s.mes = i; notifyListeners(); _save(); }

  void setIngreso(double v) {
    final mes = _s.getMes(_s.mes);
    mes.bruto = v; mes.ingNeto = v; _recalcSeg(); notifyListeners(); _save();
  }

  void setSegActiva(bool v) {
    _s.getMes(_s.mes).segActiva = v; _recalcSeg(); notifyListeners(); _save();
  }

  void setArl(double v) {
    _s.getMes(_s.mes).arl = v; _recalcSeg(); notifyListeners(); _save();
  }

  void _recalcSeg() {
    final mes = _s.getMes(_s.mes);
    mes.ingNeto = mes.segActiva && mes.bruto > 0 ? mes.bruto - mes.segTotal : mes.bruto;
  }

  void addMovimiento(Movimiento m) {
    _s.getMes(_s.mes).movimientos.add(m); notifyListeners(); _save();
  }

  void deleteMovimiento(int id) {
    _s.getMes(_s.mes).movimientos.removeWhere((m) => m.id == id); notifyListeners(); _save();
  }

  void saveCats(List<Categoria> cats) { _s.cats = cats; notifyListeners(); _save(); }

  void borrarMes() { _s.meses.remove(_s.mes); notifyListeners(); _save(); }

  Map<String, Map<String, double>> getSaldos() {
    final mes = _s.getMes(_s.mes);
    final movs = mes.movimientos;
    final ingBase = mes.ingBase;
    final segT = mes.segTotal;
    return { for (final cat in _s.cats)
      cat.n: () {
        final asig = cat.seg && mes.segActiva ? segT : ingBase * (cat.pct / 100);
        final g = movs.where((m) => m.cat == cat.n && m.tipo == 'Gasto').fold(0.0, (s, m) => s + m.val);
        final i = movs.where((m) => m.cat == cat.n && m.tipo == 'Ingreso').fold(0.0, (s, m) => s + m.val);
        return {'asignado': asig, 'gastado': g, 'ingresado': i, 'saldo': asig + i - g,
          'pctUsado': asig > 0 ? (g / asig).clamp(0.0, 1.0) : 0.0};
      }()
    };
  }

  String buildCSV() {
    const meses = ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
        'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    final esc = (dynamic v) => '"${v.toString().replaceAll('"', '""')}"';
    final rows = [['Mes','Fecha','Tipo','Categoría','Detalle','Valor']];
    final resumen = [<dynamic>[''], ['=== RESUMEN POR BOLSILLO ==='],
        ['Mes','Bolsillo','Asignado','Gastado','Ingresado','Saldo']];

    _s.meses.forEach((idx, d) {
      final mn = meses[idx];
      final movs = d.movimientos;
      final ingBase = d.ingBase;
      final segT = d.segTotal;
      if (d.bruto > 0) rows.add([mn, '', 'Ingreso Bruto', '—', 'Ingreso del mes', d.bruto]);
      if (d.segActiva && segT > 0) rows.add([mn, '', 'Seg.Social', '—', 'Salud+Pensión+ARL', segT]);
      for (final m in movs) rows.add([mn, m.fecha, m.tipo, m.cat, m.det, m.val]);
      for (final cat in _s.cats) {
        final asig = cat.seg && d.segActiva ? segT : ingBase * (cat.pct / 100);
        final g = movs.where((m) => m.cat == cat.n && m.tipo == 'Gasto').fold(0.0, (s, m) => s + m.val);
        final i = movs.where((m) => m.cat == cat.n && m.tipo == 'Ingreso').fold(0.0, (s, m) => s + m.val);
        resumen.add([mn, cat.n, asig, g, i, asig + i - g]);
      }
    });

    return '\uFEFF${[...rows, ...resumen].map((r) => r.map(esc).join(',')).join('\n')}';
  }
}
