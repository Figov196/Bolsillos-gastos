// lib/widgets/bolsillo_card.dart
import 'package:flutter/material.dart';
import '../models.dart';
import '../theme.dart';

class BolsilloCard extends StatelessWidget {
  final Categoria cat;
  final Map<String, double> data;
  const BolsilloCard({super.key, required this.cat, required this.data});

  @override
  Widget build(BuildContext context) {
    final saldo = data['saldo']!;
    final asignado = data['asignado']!;
    final gastado = data['gastado']!;
    final pctUsado = data['pctUsado']!;
    final neg = saldo < 0;

    return Container(
      decoration: BoxDecoration(
        color: kS1, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cat.seg ? kA3.withOpacity(0.3) : kBorder),
      ),
      child: Stack(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(cat.n,
                style: const TextStyle(fontSize: 10, color: kMuted, letterSpacing: 0.8),
                maxLines: 1, overflow: TextOverflow.ellipsis)),
              if (cat.seg) Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(color: kA3.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                child: const Text('auto', style: TextStyle(fontSize: 9, color: kA3)),
              ),
            ]),
            const SizedBox(height: 6),
            Text(fCOP(saldo), style: syneStyle(size: 15, color: neg ? kDanger : kText)),
            const SizedBox(height: 3),
            Text('Asig: ${fCOP(asignado)}', style: const TextStyle(fontSize: 10, color: kA2)),
            const SizedBox(height: 2),
            Text('Gasto: ${fCOP(gastado)}', style: const TextStyle(fontSize: 10, color: kMuted)),
          ]),
        ),
        Positioned(bottom: 0, left: 0, right: 0,
          child: ClipRRect(
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(14), bottomRight: Radius.circular(14)),
            child: LinearProgressIndicator(
              value: pctUsado, backgroundColor: kBorder, minHeight: 3,
              valueColor: AlwaysStoppedAnimation(neg ? kDanger : kAccent),
            ),
          )),
      ]),
    );
  }
}
