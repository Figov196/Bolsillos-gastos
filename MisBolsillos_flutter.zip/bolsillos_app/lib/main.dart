// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'services/drive_service.dart';
import 'state.dart';
import 'theme.dart';
import 'screens/resumen_screen.dart';
import 'screens/registrar_screen.dart';
import 'screens/historial_screen.dart';
import 'screens/config_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: kS1,
  ));
  await DriveService.signInSilently();
  runApp(ChangeNotifierProvider(
    create: (_) => BolsillosProvider(),
    child: const MisBolsillosApp(),
  ));
}

class MisBolsillosApp extends StatelessWidget {
  const MisBolsillosApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Mis Bolsillos',
    debugShowCheckedModeBanner: false,
    theme: appTheme(),
    home: const HomeScreen(),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;

  static const _screens = [
    ResumenScreen(), RegistrarScreen(), HistorialScreen(), ConfigScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: RichText(text: TextSpan(
          style: GoogleFonts.syne(fontSize: 18, fontWeight: FontWeight.w800, color: kText),
          children: const [
            TextSpan(text: 'Mis '),
            TextSpan(text: 'Bolsillos', style: TextStyle(color: kAccent)),
          ],
        )),
        actions: [
          Padding(padding: const EdgeInsets.only(right: 8),
            child: Center(child: Consumer<BolsillosProvider>(builder: (_, prov, __) {
              final mes = prov.s.getMes(prov.s.mes);
              if (mes.bruto == 0) return const SizedBox();
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: kAccent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20), border: Border.all(color: kAccent.withOpacity(0.3))),
                child: Text(fCOP(mes.bruto), style: const TextStyle(fontSize: 12, color: kAccent, fontFamily: 'DM Mono')));
            }))),
        ],
      ),
      body: IndexedStack(index: _tab, children: _screens),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(border: Border(top: BorderSide(color: kBorder))),
        child: BottomNavigationBar(
          currentIndex: _tab,
          onTap: (i) => setState(() => _tab = i),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet_outlined), activeIcon: Icon(Icons.account_balance_wallet), label: 'Resumen'),
            BottomNavigationBarItem(icon: Icon(Icons.add_circle_outline), activeIcon: Icon(Icons.add_circle), label: 'Registrar'),
            BottomNavigationBarItem(icon: Icon(Icons.receipt_long_outlined), activeIcon: Icon(Icons.receipt_long), label: 'Historial'),
            BottomNavigationBarItem(icon: Icon(Icons.settings_outlined), activeIcon: Icon(Icons.settings), label: 'Config'),
          ],
        ),
      ),
    );
  }
}
